#ifndef __NODE_LIST_H__
#define __NODE_LIST_H__

#define NL_BLOCK          1
#define NL_NO_BLOCK       0

#define NL_KEEPUPDATE     1
#define NL_NO_KEEPUPDATE  0
#define NL_DATA_ADDR_NUM  8

#ifndef FOR_64BIT_SYSTEM
typedef uint32_t addr_t;
#else
typedef uint64_t addr_t;
#endif
typedef struct node {
	struct list_head head;
	unsigned int size;		/* reserved for future use */
	void *data;			/* need alloc memory */
	addr_t data_phy;		/* physical address of data */
	addr_t data_mmap;		/*virtual addr from mmap by user*/
	unsigned int crc32;			/* crc32 */
	addr_t private;                    /* private */
	int width;
	int height;
	int video_size;
	char ts[16];
} node_t;

typedef struct data_addr_struct {
	addr_t addr_phy[NL_DATA_ADDR_NUM];
	void   *addr_vir[NL_DATA_ADDR_NUM];
}data_addr_t;

typedef struct node_list {
	unsigned int free_cnt;
	struct list_head free;	/* free list */
	unsigned int use_cnt;
	struct list_head use;	/* use list */
	struct completion comp_use;	/* use for blockd read */
	struct completion comp_free;	/* use for blockd read */
	spinlock_t lock;
	void *data_addr;			/* data head */
	int keep_update;        /* keep update */
	int producer_block;
	int consumer_block;
	int size;               /* node memory size */
	unsigned int nodes;     /* total node */
} node_list_t;

node_t *get_use_node(node_list_t *list);
int put_free_node(node_list_t *list, node_t *node);
node_t *get_free_node(node_list_t *list);
int put_use_node(node_list_t *list, node_t *node);
int drop_use_node(node_list_t *list, node_t *node_ref);
node_list_t *init_node_list(int nodes, int size, int producer_block,
							int consumer_block, int keep_update, struct usb_device *udev);

#endif //__NODE_LIST_H__
