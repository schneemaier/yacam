/*
 * motor.c - Ingenic motor driver
 *
 * Copyright (C) 2015 Ingenic Semiconductor Co.,Ltd
 *       http://www.ingenic.com
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <linux/mm.h>
#include <linux/fs.h>
#include <linux/clk.h>
#include <linux/pwm.h>
#include <linux/file.h>
#include <linux/list.h>
#include <linux/gpio.h>
#include <linux/time.h>
#include <linux/sched.h>
#include <linux/delay.h>
#include <linux/module.h>
#include <linux/debugfs.h>
#include <linux/kthread.h>
#include <linux/mfd/core.h>
#include <linux/mempolicy.h>
#include <linux/interrupt.h>
#include <linux/mfd/jz_tcu.h>
#include <linux/miscdevice.h>
#include <linux/platform_device.h>

#include <soc/irq.h>
#include <soc/base.h>
#include <soc/extal.h>

#include <asm/io.h>
#include <asm/irq.h>
#include <asm/uaccess.h>
#include <asm/cacheflush.h>
#include <soc/gpio.h>
#include <mach/platform.h>
#include "motor.h"
#define JZ_MOTOR_DRIVER_VERSION "H20171204a"
#define HMOTOR2VMOTORRATIO 1
static unsigned int hmotor2vmotor = 1;
module_param(hmotor2vmotor, int, S_IRUGO);
MODULE_PARM_DESC(hmotor2vmotor, "The value is hmotor's speed / vmotor's");


static unsigned int hmaxstep = 2590;
module_param(hmaxstep, int, S_IRUGO);
MODULE_PARM_DESC(hmaxstep, "The max steps of horizontal motor");

static unsigned int vmaxstep = 710;
module_param(vmaxstep, int, S_IRUGO);
MODULE_PARM_DESC(vmaxstep, "The max steps of vertical motor");

//extern int jzgpio_ctrl_pull(enum gpio_port port, int enable_pull,unsigned long pins);

struct motor_platform_data motors_pdata[HAS_MOTOR_CNT] = {
	{
		.name = "Horizontal motor",
		.motor_min_gpio		= HORIZONTAL_MIN_GPIO,
		.motor_max_gpio 	= HORIZONTAL_MAX_GPIO,
		.motor_gpio_level	= HORIZONTAL_GPIO_LEVEL,
		.motor_st1_gpio		= HORIZONTAL_ST1_GPIO,
		.motor_st2_gpio		= HORIZONTAL_ST2_GPIO,
		.motor_st3_gpio		= HORIZONTAL_ST3_GPIO,
		.motor_st4_gpio		= HORIZONTAL_ST4_GPIO,
		.motor_enable		= HORIZONTAL_ENABLE,
	},
	{
		.name = "Vertical motor",
		.motor_min_gpio		= VERTICAL_MIN_GPIO,
		.motor_max_gpio 	= VERTICAL_MAX_GPIO,
		.motor_gpio_level	= VERTICAL_GPIO_LEVEL,
		.motor_st1_gpio		= VERTICAL_ST1_GPIO,
		.motor_st2_gpio		= VERTICAL_ST2_GPIO,
		.motor_st3_gpio		= VERTICAL_ST3_GPIO,
		.motor_st4_gpio		= VERTICAL_ST4_GPIO,
		.motor_enable		= VERTICAL_ENABLE,
	},
};

//10000的timer速度下，对应的计数值与实际速度
const int g_traceSpeedList[HL_NUM_OF_LEVEL] = {
		19,	//5000/19=263
		18,	//5000/18=277
		17,	//5000/17=294
		15,	//5000/15=333
		12,	//5000/12=416
		11,	//5000/11=454
		10,	//5000/10=500
		9,	//5000/9 =555
		8,	//5000/8 =625
		7,	//5000/7 =714
		7,	//5000/6 =833
		6,	//
		6,	//
		6,	//
		6,	//
		6,	//5000/5 =1000
		5,	//
		5,	//
		6,	//
		8,	//5000/5 =1000
};

/*******************************************************************************
功能描述: 电机参数初始化：
		总设备状态置为stop，每个电机的运行状态都置位stop，每个电机引脚电平置位低。
输入参数: 无
输出参数: mdev //电机设备总管理结构
返回值域: 无
--------------------------------------------------------------------------------
修改作者: ChenX
修改日期: 2018.6.
修改说明: 实现
*******************************************************************************/
static void motor_set_default(struct motor_device *mdev)
{
	int index = 0;
	struct motor_driver *motor = NULL;
	mdev->dev_state = MOTOR_OPS_STOP;
	for(index = 0; index < HAS_MOTOR_CNT; index++)
	{
		motor =  &mdev->motors[index];
		motor->state = MOTOR_OPS_STOP;
		if (motor->pdata->motor_enable)
		{
			gpio_direction_output(motor->pdata->motor_st1_gpio, 0);
			gpio_direction_output(motor->pdata->motor_st2_gpio, 0);
			gpio_direction_output(motor->pdata->motor_st3_gpio, 0);
			gpio_direction_output(motor->pdata->motor_st4_gpio, 0);
		}
	}
	return;
}

//8拍，每步的输出状态
static unsigned char step_8[8] = {
	0x08,			//0b 0000 1000
	0x0c,			//0b 0000 1100
	0x04,			//0b 0000 0100
	0x06,			//0b 0000 0110
	0x02,			//0b 0000 0010
	0x03,			//0b 0000 0011
	0x01,			//0b 0000 0001
	0x09			//0b 0000 1001
};

/*******************************************************************************
功能描述: 某个电机模块输出输出cur_steps对应的脉冲，若是复位模式总步数计数加1
输入参数: index 电机号
输出参数: mdev //电机设备总管理结构
返回值域: 无
--------------------------------------------------------------------------------
修改作者: ChenX
修改日期: 2018.6.
修改说明: 实现
*******************************************************************************/
static void motor_move_step(struct motor_device *mdev, int index)
{
	struct motor_driver *motor = NULL;
	int step = 0;

	motor =  &mdev->motors[index];			//某个电机模块
	//输出当前步数
	if(motor->state != MOTOR_OPS_STOP)		//如果电机运行
	{
		step = motor->cur_steps % 8;
		step = step < 0 ? step + 8 : step;	//当前步数
		//输出当前步数
		if (motor->pdata->motor_enable)
		{
			gpio_direction_output(motor->pdata->motor_st1_gpio, step_8[step] & 0x8);
			gpio_direction_output(motor->pdata->motor_st2_gpio, step_8[step] & 0x4);
			gpio_direction_output(motor->pdata->motor_st3_gpio, step_8[step] & 0x2);
			gpio_direction_output(motor->pdata->motor_st4_gpio, step_8[step] & 0x1);
		}
	}
	else
	{
		if (motor->pdata->motor_enable)
		{
			gpio_direction_output(motor->pdata->motor_st1_gpio, 0);
			gpio_direction_output(motor->pdata->motor_st2_gpio, 0);
			gpio_direction_output(motor->pdata->motor_st3_gpio, 0);
			gpio_direction_output(motor->pdata->motor_st4_gpio, 0);
		}
	}
	//若是复位，总步数加1
	if(motor->state == MOTOR_OPS_RESET)
	{
		motor->total_steps++;
	}

	return;
}

/*******************************************************************************
功能描述: 某电机到最小位置时的操作。当前步数置0
		【常规模式下】，若电机逆时针转，则置停。
		【巡航模式下】，置顺时针转（置成反方向）
输入参数: index 电机号
输出参数: mdev //电机设备总管理结构
返回值域: 无
--------------------------------------------------------------------------------
修改作者: ChenX
修改日期: 2018.6.
修改说明: 实现
*******************************************************************************/
static void move_to_min_pose_ops(struct motor_driver *motor)
{
	//	printk("%s min %d\n",motor->pdata->name,__LINE__);
	if(motor->state == MOTOR_OPS_RESET)
	{
		/* motor->state = MOTOR_OPS_STOP; */
		/* //	complete(&motor->reset_completion); */
		/* motor->move_dir = MOTOR_MOVE_RIGHT_UP; */
	}
	else if(motor->state == MOTOR_OPS_CRUISE)
	{
		motor->move_dir = MOTOR_MOVE_RIGHT_UP;
	}
	else //if(motor->state == MOTOR_OPS_NORMAL)
	{
		if(motor->move_dir == MOTOR_MOVE_LEFT_DOWN)
		{
			motor->state = MOTOR_OPS_STOP;
		}
	}
	motor->cur_steps = 0;
	//printk("%s min; cur_steps = %d max_steps = %d\n", motor->pdata->name,motor->cur_steps, motor->max_steps);
}

/*******************************************************************************
功能描述: 某电机到最大位置时的操作。当前步数置max
		【复位状态时】电机停止，最大步数被赋值成默认值。通知复位完成，方向置成逆。
		【常规模式下】，若电机顺时针转，则置停。
		【巡航模式下】，方向置逆（置成反方向）
输入参数: index 电机号
输出参数: mdev //电机设备总管理结构
返回值域: 无
--------------------------------------------------------------------------------
修改作者: ChenX
修改日期: 2018.6.
修改说明: 实现
*******************************************************************************/
static void move_to_max_pose_ops(struct motor_driver *motor,int index)
{
	if(motor->state == MOTOR_OPS_RESET)
	{
		motor->state = MOTOR_OPS_STOP;

		if(index ==HORIZONTAL_MOTOR)
			motor->max_steps=hmaxstep;
		else
			motor->max_steps=vmaxstep;

		complete(&motor->reset_completion);
		motor->move_dir = MOTOR_MOVE_LEFT_DOWN;

	}
	else if(motor->state == MOTOR_OPS_CRUISE)
	{
		motor->move_dir = MOTOR_MOVE_LEFT_DOWN;
	}
	else //if(motor->state == MOTOR_OPS_NORMAL)
	{
		if(motor->move_dir == MOTOR_MOVE_RIGHT_UP)
		{
			motor->state = MOTOR_OPS_STOP;
		}
	}
	motor->cur_steps = motor->max_steps;
	//printk("%s max; cur_steps = %d max_steps = %d\n", motor->pdata->name,motor->cur_steps, motor->max_steps);
}

//跳步数组
static char skip_move_mode[4][4] = {
					{2,1,1,1},
				    {3,2,1,1},
				    {4,3,2,1},
				    {3,3,2,1}
};


/*******************************************************************************
功能描述: 根据步数选择跳步数组
输入参数: steps 步数
输出参数: mdev //电机设备总管理结构
返回值域: 无
--------------------------------------------------------------------------------
修改作者: ChenX
修改日期: 2018.6.
修改说明: 实现
*******************************************************************************/
static inline void calc_slow_mode(struct motor_device *mdev, unsigned int steps)
{
	int index = steps / 10;
	index = index > 3 ? 3 : index;
	mdev->skip_mode = skip_move_mode[index];
}

/*******************************************************************************
功能描述: 判断每隔多少步一停
输入参数: remainder 步数差值
输出参数: mdev //电机设备总管理结构
返回值域: return: 1 --> move, 0 --> don't move
--------------------------------------------------------------------------------
修改作者: ChenX
修改日期: 2018.6.
修改说明: 实现
*******************************************************************************/
static inline int whether_move_func(struct motor_device *mdev, unsigned int remainder)
{
	if(remainder == 0)
		return 0;
	return 1;
	remainder = remainder / 15;
	remainder = remainder > 3 ? 3: remainder;
	if(mdev->counter % mdev->skip_mode[remainder] == 0)		//此处有个大bug （余0）
		return 1;
	else
		return 0;
}


static void hl_trace_handle(struct motor_device *mdev)
{
	//struct motor_driver *motors = mdev->motors;			//单个电机状态管理结构
	//int motorIndex = 0;



}

/*******************************************************************************
功能描述: 追踪移动操作  处理函数
		给出期望步数； 方向；  置常规移动状态
输入参数: x y 要移动的步数
输出参数: mdev //电机设备总管理结构
返回值域:
--------------------------------------------------------------------------------
修改作者: ChenX
修改日期: 2018.6.
修改说明: 实现
*******************************************************************************/
static long motor_ops_trace(struct motor_device *mdev, int dx, int dy)
{
	struct motor_driver *motors = mdev->motors;
	unsigned long flags;

	if (mdev->dev_state == MOTOR_OPS_NORMAL || mdev->dev_state == MOTOR_OPS_RESET)
	{
		return 0;
	}
	//锁
	mutex_lock(&mdev->dev_mutex);
	//spin_lock_irqsave(&mdev->slock, flags);

	mdev->traceCmdTimeout = HL_TRACE_CMD_TIMEOUT;	//更新cmd超时值,超时则减速停止
	//mdev->wait_stop = 1;							//置“还没停标志位”	2018-7-10 09:09:35 - DEL

	//x  0到320	找出目标等级(hl_traceDst) 及 方向  （对应着目标速度）
	do{
		if (dx >= 0)
		{
			//设置置目旋转标方向，(此处不改实际旋转方向)
			motors[HORIZONTAL_MOTOR].hl_traceDstDir = MOTOR_MOVE_RIGHT_UP;
		}
		else
		{
			motors[HORIZONTAL_MOTOR].hl_traceDstDir = MOTOR_MOVE_LEFT_DOWN;
			dx = -dx;
		}
		//在中间区域内，减速停止
		if (dx < HL_STOP_TRACE_RANGE_X || dx > 300)
		{
			motors[HORIZONTAL_MOTOR].hl_traceStop = 1;					//欲减速停止
			break;
		}
		//cut in,no trace最高速的位置
		// if ((mdev->traceStopTime >= HL_TRACE_STOP_TIME_MAX) &&
		// 		(dx > HL_STOP_TRACE_CUTIN_X))
		// {
		// 	motors[HORIZONTAL_MOTOR].hl_traceStop = 1;					//欲减速停止
		// 	break;
		// }
		//当前实际旋转方向  与  目标方向  不一致则减速（停止后，会在中断级里改变实际方向）
		if ((motors[HORIZONTAL_MOTOR].state == MOTOR_OPS_TRACE) &&
				(motors[HORIZONTAL_MOTOR].hl_traceDstDir != motors[HORIZONTAL_MOTOR].move_dir))
		{
			motors[HORIZONTAL_MOTOR].hl_traceStop = 1;					//欲减速停止
			break;
		}
		else
		{
			motors[HORIZONTAL_MOTOR].move_dir = motors[HORIZONTAL_MOTOR].hl_traceDstDir;
		}
		//利用坐标设置转速度级别
		motors[HORIZONTAL_MOTOR].hl_traceDst = ((dx - HL_STOP_TRACE_RANGE_X) / HL_TRACE_X_MUL);
		if (motors[HORIZONTAL_MOTOR].hl_traceDst > (HL_NUM_OF_LEVEL-1))
		{
			motors[HORIZONTAL_MOTOR].hl_traceDst = (HL_NUM_OF_LEVEL-1);
		}
		motors[HORIZONTAL_MOTOR].hl_traceStop = 0;				//不停止
		motors[HORIZONTAL_MOTOR].state = MOTOR_OPS_TRACE;		//电机的状态置成不停
	}while(0);

	//y  0到180	找出目标等级(hl_traceDst) 及 方向  （对应着目标速度）
	do{
		if (dy >= 0)
		{
			motors[VERTICAL_MOTOR].hl_traceDstDir = MOTOR_MOVE_RIGHT_UP;
		}
		else
		{
			motors[VERTICAL_MOTOR].hl_traceDstDir = MOTOR_MOVE_LEFT_DOWN;		//确定方向
			dy = -dy;
		}
		//在中间区域内，减速停止
		if (dy < HL_STOP_TRACE_RANGE_Y || dy > 135)
		{
			motors[VERTICAL_MOTOR].hl_traceStop = 1;			//停止
			break;
		}
		//cut in,no trace最高速的位置
		// if ((mdev->traceStopTime >= HL_TRACE_STOP_TIME_MAX) &&
		// 		(dy > HL_STOP_TRACE_CUTIN_Y))
		// {
		// 	motors[VERTICAL_MOTOR].hl_traceStop = 1;					//欲减速停止
		// 	break;
		// }
		//当前实际旋转方向  与  目标方向  不一致则减速（停止后，会在中断级里改变实际方向）
		if ((motors[VERTICAL_MOTOR].state == MOTOR_OPS_TRACE) &&
				(motors[VERTICAL_MOTOR].hl_traceDstDir != motors[VERTICAL_MOTOR].move_dir))
		{
			motors[VERTICAL_MOTOR].hl_traceStop = 1;					//欲减速停止
			break;
		}
		else
		{
			motors[VERTICAL_MOTOR].move_dir = motors[VERTICAL_MOTOR].hl_traceDstDir;
		}
		//利用坐标设置转速度级别
		motors[VERTICAL_MOTOR].hl_traceDst = ((dy - HL_STOP_TRACE_RANGE_Y) / HL_TRACE_Y_MUL);
		if (motors[VERTICAL_MOTOR].hl_traceDst > (HL_NUM_OF_LEVEL-1))
		{
			motors[VERTICAL_MOTOR].hl_traceDst = (HL_NUM_OF_LEVEL-1);
		}
		motors[VERTICAL_MOTOR].hl_traceStop = 0;				//不停止
		motors[VERTICAL_MOTOR].state = MOTOR_OPS_TRACE;			//电机的状态置成不停
	}while(0);

	mdev->dev_state = MOTOR_OPS_TRACE;				//追踪模式
	//解锁
	//spin_unlock_irqrestore(&mdev->slock, flags);
	mutex_unlock(&mdev->dev_mutex);
#if DRIVER_DEBUG
	printk("stop:%d  state:%d  traceDst:%d  traceCur:%d  DstDir:%d  moveDir:%d\n",
											motors[HORIZONTAL_MOTOR].hl_traceStop,
											motors[HORIZONTAL_MOTOR].state,
											motors[HORIZONTAL_MOTOR].hl_traceDst,
											motors[HORIZONTAL_MOTOR].hl_traceCur,
											motors[HORIZONTAL_MOTOR].hl_traceDstDir,
											motors[HORIZONTAL_MOTOR].move_dir);
#endif
	//若没有其他地方使能tcu，则使能
	//if (mdev->hl_tcuDisableFlag == 1)
	//{
		jz_tcu_enable_counter(mdev->tcu);
	//}
	return 0;
	/* check x value */
}
/*******************************************************************************
功能描述: timer中断服务函数
输入参数:
输出参数: dev_id //电机设备总管理结构
返回值域:
--------------------------------------------------------------------------------
修改作者: ChenX
修改日期: 2018.6.
修改说明: 实现
*******************************************************************************/
static irqreturn_t jz_timer_interrupt(int irq, void *dev_id)
{
	struct motor_device *mdev = dev_id;					//电机设备总管理结构
	struct motor_move *dst = &mdev->dst_move;			//目标移动参数
	struct motor_move *cur = &mdev->cur_move;			//当前移动参数
	struct motor_driver *motors = mdev->motors;			//单个电机状态管理结构
	int motorIndex = 0;

	if(mdev->dev_state == MOTOR_OPS_TRACE)
	{
		//hl_trace_handle(mdev);
		//解决长时间无反馈值问题，100ms没反馈，将自动置减速
		if (mdev->traceCmdTimeout > 0)
		{
			mdev->traceCmdTimeout--;
		}
		else
		{
			motors[HORIZONTAL_MOTOR].hl_traceStop = 1;		//置此标志，将减速直到停止
			motors[VERTICAL_MOTOR].hl_traceStop   = 1;		//置此标志，将减速直到停止
		}
		//改变速度计数
		mdev->hl_exchangeSpeedTimeout++;
		if (mdev->hl_exchangeSpeedTimeout >= HL_EXCHANGE_SPEED_LVL_CNT)	//到时间了(25ms允许改变速度一次)
		{
			mdev->hl_exchangeSpeedTimeout = 0;
		}

		//每路电机的  速度改变  及  输出
		for (; motorIndex < HAS_MOTOR_CNT; motorIndex++)
		{
			if (motors[motorIndex].state != MOTOR_OPS_STOP)
			{
				//mdev->traceStopTime = 0;			//clean count flag
				//改变速度
				if (!mdev->hl_exchangeSpeedTimeout)			//到时间了允许改变速度一次
				{
					if (motors[motorIndex].hl_traceStop )	//若标志为1，强行减速
					{
						if (motors[motorIndex].hl_traceCur > 0)
						{
							motors[motorIndex].hl_traceCur--;
						}
						else
						{
							motors[motorIndex].state = MOTOR_OPS_STOP;
							//change dir in there?
							continue;
						}
					}
					else									//若标志为0，正常改变速度等级
					{
						if (motors[motorIndex].hl_traceDst > motors[motorIndex].hl_traceCur)		//还需要加速
						{
							motors[motorIndex].hl_traceCur++;
						}
						else if (motors[motorIndex].hl_traceDst < motors[motorIndex].hl_traceCur)	//还需要减速
						{
							motors[motorIndex].hl_traceCur--;
						}
					}
				}
				//输出
				motors[motorIndex].hl_traceCurCount++;
				if (motors[motorIndex].hl_traceCurCount >=
						g_traceSpeedList[motors[motorIndex].hl_traceCur])			//次数到达输出次数
				{
					motors[motorIndex].hl_traceCurCount = 0;
					motors[motorIndex].cur_steps += motors[motorIndex].move_dir;		//增加步数
					motor_move_step(mdev, motorIndex);									//输出一个脉冲
				}
			}
		}
	}
	else
	{
		//不是追踪模式时，清除当前当前等级
		motors[HORIZONTAL_MOTOR].hl_traceCur = 0;
		motors[VERTICAL_MOTOR].hl_traceCur = 0;
	}

	// if((mdev->dev_state == MOTOR_OPS_STOP) 
	// 		&& (mdev->traceStopTime < HL_TRACE_STOP_TIME_MAX))
	// {
	// 	mdev->traceStopTime++;
	// }

	motors[0].hl_outputCurCount++;

	if (motors[0].hl_outputCurCount
			>= g_traceSpeedList[motors[0].hl_outputDst])
	{
		motors[0].hl_outputCurCount = 0;
	}
	else
	{
		return IRQ_HANDLED;
	}

	//所有电机都停了
	if(motors[HORIZONTAL_MOTOR].state == MOTOR_OPS_STOP
			&& motors[VERTICAL_MOTOR].state == MOTOR_OPS_STOP)
	{
		if (mdev->dev_state != MOTOR_OPS_STOP)
		{
			mdev->dev_state = MOTOR_OPS_STOP;
			motor_move_step(mdev, HORIZONTAL_MOTOR);		//输出置0
			motor_move_step(mdev, VERTICAL_MOTOR);			//输出置0
			if(mdev->wait_stop)								//若还没发停止消息
			{
				mdev->wait_stop = 0;						//发消息给内核已经停止
				complete(&mdev->stop_completion);			//发消息给内核已经停止
			}
		}
		return IRQ_HANDLED;
	}

	//转到头了（最小位置）
	if(motors[HORIZONTAL_MOTOR].cur_steps <= 0)
		move_to_min_pose_ops(&motors[HORIZONTAL_MOTOR]);
	//转到头了（最大位置）
	if(motors[HORIZONTAL_MOTOR].cur_steps >= motors[HORIZONTAL_MOTOR].max_steps)
		move_to_max_pose_ops(&motors[HORIZONTAL_MOTOR],HORIZONTAL_MOTOR);

	if(motors[VERTICAL_MOTOR].cur_steps <= 0)
		move_to_min_pose_ops(&motors[VERTICAL_MOTOR]);

	if(motors[VERTICAL_MOTOR].cur_steps >= motors[VERTICAL_MOTOR].max_steps)
		move_to_max_pose_ops(&motors[VERTICAL_MOTOR],VERTICAL_MOTOR);

	//巡航状态
	if(mdev->dev_state == MOTOR_OPS_CRUISE)
	{
		mdev->counter++;	//步数计数增加

		motors[HORIZONTAL_MOTOR].cur_steps += motors[HORIZONTAL_MOTOR].move_dir;//增加步数
		//if(mdev->counter % hmotor2vmotor == 0)								//利用执行次数改变转动速度
		motors[VERTICAL_MOTOR].cur_steps += motors[VERTICAL_MOTOR].move_dir;	//增加步数

		motor_move_step(mdev, HORIZONTAL_MOTOR);								//输出cur_steps的脉冲
		motor_move_step(mdev, VERTICAL_MOTOR);									//输出cur_steps的脉冲
	}

	//复位状态
	else if(mdev->dev_state == MOTOR_OPS_RESET)
	{
		if(motors[HORIZONTAL_MOTOR].state != MOTOR_OPS_STOP)
		{
			motors[HORIZONTAL_MOTOR].cur_steps += motors[HORIZONTAL_MOTOR].move_dir;//增加步数
			motor_move_step(mdev, HORIZONTAL_MOTOR);								//输出cur_steps的脉冲
			cur->one.x++;		//移动参数的坐标值++
		}
		if(motors[VERTICAL_MOTOR].state != MOTOR_OPS_STOP)
		{
			motors[VERTICAL_MOTOR].cur_steps += motors[VERTICAL_MOTOR].move_dir;	//增加步数
			motor_move_step(mdev, VERTICAL_MOTOR);									//输出cur_steps的脉冲
			cur->one.y++;		//移动参数的坐标值++
		}
	}

	//常规状态
	else if(mdev->dev_state == MOTOR_OPS_NORMAL)
	{
		mdev->counter++;	//步数计数增加
		//判断到了步数，则置停
		if(cur->one.x < dst->one.x && motors[HORIZONTAL_MOTOR].state != MOTOR_OPS_STOP)
		{
			if(whether_move_func(mdev, dst->one.x - cur->one.x))		//若判断转
			{
				motors[HORIZONTAL_MOTOR].cur_steps += motors[HORIZONTAL_MOTOR].move_dir;
				motor_move_step(mdev, HORIZONTAL_MOTOR);
				cur->one.x++;
			}
		}
		else
		{
			motors[HORIZONTAL_MOTOR].state = MOTOR_OPS_STOP;
		}

		if(cur->one.y < dst->one.y && motors[VERTICAL_MOTOR].state != MOTOR_OPS_STOP)
		{
			//if(mdev->counter % hmotor2vmotor == 0)
			//{
			motors[VERTICAL_MOTOR].cur_steps += motors[VERTICAL_MOTOR].move_dir;
			motor_move_step(mdev, VERTICAL_MOTOR);
			cur->one.y++;
			//}
		}
		else
		{
			motors[VERTICAL_MOTOR].state = MOTOR_OPS_STOP;
		}
	}
	return IRQ_HANDLED;
}

/*******************************************************************************
功能描述: 常规移动操作  处理函数
		给出期望步数； 方向；  置常规移动状态
输入参数: x y 要移动的步数
输出参数: mdev //电机设备总管理结构
返回值域:
--------------------------------------------------------------------------------
修改作者: ChenX
修改日期: 2018.6.
修改说明: 实现
*******************************************************************************/
static long motor_ops_move(struct motor_device *mdev, int x, int y)
{
	struct motor_driver *motors = mdev->motors;
	unsigned long flags;
	int x_dir = MOTOR_MOVE_STOP;
	int y_dir = MOTOR_MOVE_STOP;
	int x1 = 0;
	int y1 = 0;
	/* check x value */
	if(x > 0)
	{
		if(motors[HORIZONTAL_MOTOR].cur_steps >= motors[HORIZONTAL_MOTOR].max_steps)
			x = 0;
	}
	else
	{
		if(motors[HORIZONTAL_MOTOR].cur_steps <= 0)
			x = 0;
	}
	/* check y value */
	if(y > 0)
	{
		if(motors[VERTICAL_MOTOR].cur_steps >= motors[VERTICAL_MOTOR].max_steps)
			y = 0;
	}
	else
	{
		if(motors[VERTICAL_MOTOR].cur_steps <= 0)
			y = 0;
	}

	/*x_dir = x > 0 ? MOTOR_MOVE_RIGHT_UP : (x < 0 ? MOTOR_MOVE_LEFT_DOWN: MOTOR_MOVE_STOP);*/
	/*y_dir = y > 0 ? MOTOR_MOVE_RIGHT_UP : (y < 0 ? MOTOR_MOVE_LEFT_DOWN: MOTOR_MOVE_STOP);*/
	//判断方向
	x_dir = x > 0 ? MOTOR_MOVE_RIGHT_UP : MOTOR_MOVE_LEFT_DOWN;
	y_dir = y > 0 ? MOTOR_MOVE_RIGHT_UP : MOTOR_MOVE_LEFT_DOWN;
	//判断步数
	x1 = x < 0 ? 0 - x : x;
	y1 = y < 0 ? 0 - y : y;

	if(x1 + y1 == 0)
		return 0;

	mutex_lock(&mdev->dev_mutex);
	spin_lock_irqsave(&mdev->slock, flags);
	//根据步数选择跳步数组
	calc_slow_mode(mdev, x1);				//一定会选择最后的那行数组

	mdev->counter = 0;						//计数清零
	mdev->dev_state = MOTOR_OPS_NORMAL;		//置常规移动模式
	mdev->dst_move.one.x = x1;
	mdev->dst_move.one.y = y1;				//赋值期望转动步数
	mdev->cur_move.one.x = 0;
	mdev->cur_move.one.y = 0;				//清0当前转动步数
	motors[HORIZONTAL_MOTOR].state = MOTOR_OPS_NORMAL;			//每个电机 置常规移动模式
	motors[HORIZONTAL_MOTOR].move_dir = x_dir;					//置每个电机的方向
	motors[VERTICAL_MOTOR].state = MOTOR_OPS_NORMAL;
	motors[VERTICAL_MOTOR].move_dir = y_dir;

	spin_unlock_irqrestore(&mdev->slock, flags);
	mutex_unlock(&mdev->dev_mutex);
	/*printk("[%s] x=%d |y=%d |t=%d |x_dir=%d |y_dir=%d\n"
			,__func__, mdev->dst_move.one.x, mdev->dst_move.one.y, mdev->dst_move.times ,x_dir, y_dir); */
	jz_tcu_enable_counter(mdev->tcu);
	mdev->hl_tcuDisableFlag = 0;
	return 0;
}

/*******************************************************************************
功能描述: 停止移动操作  处理函数
输入参数:
输出参数: mdev //电机设备总管理结构
返回值域:
--------------------------------------------------------------------------------
修改作者: ChenX
修改日期: 2018.6.
修改说明: 实现
*******************************************************************************/
static void motor_ops_stop(struct motor_device *mdev)
{
	unsigned long flags;
	long ret = 0;
	unsigned int remainder = 0;
	struct motor_driver *motors = mdev->motors;
	struct motor_move *dst = &mdev->dst_move;
	struct motor_move *cur = &mdev->cur_move;


	if(mdev->dev_state == MOTOR_OPS_STOP)
		return;

	mutex_lock(&mdev->dev_mutex);
	spin_lock_irqsave(&mdev->slock, flags);

	//常规转动状态
	if(mdev->dev_state == MOTOR_OPS_NORMAL)
	{
		remainder = dst->one.x - cur->one.x;	//距离期望还差多少步
		if(remainder > 30)
		{
			dst->one.x = 29;					//将期望置成很小的值
			cur->one.x = 0;
		}

		remainder = dst->one.y - cur->one.y;	//距离期望还差多少步
		if(remainder > 8)
		{
			dst->one.y = 6;						//将期望置成很小的值
			cur->one.y = 0;
		}
	}

	//巡航模式
	if(mdev->dev_state == MOTOR_OPS_CRUISE)
	{
		mdev->dev_state = MOTOR_OPS_NORMAL;		//切到常规模式，步数什么的变量都清0，让其自己停下
		motors[HORIZONTAL_MOTOR].state = MOTOR_OPS_NORMAL;
		motors[VERTICAL_MOTOR].state = MOTOR_OPS_NORMAL;
		dst->one.x = 0;
		cur->one.x = 0;
		dst->one.y = 0;
		cur->one.y = 0;
	}

	mdev->counter = 0;
	mdev->wait_stop = 1;
	spin_unlock_irqrestore(&mdev->slock, flags);
	mutex_unlock(&mdev->dev_mutex);
	do{
		//等待停止完成
		ret = wait_for_completion_interruptible_timeout(&mdev->stop_completion, msecs_to_jiffies(15000));
		if(ret == 0)
		{
			ret = -ETIMEDOUT;
			break;
		}
	}while(ret == -ERESTARTSYS);

	jz_tcu_disable_counter(mdev->tcu);
	mdev->hl_tcuDisableFlag = 1;
	/*mdev->dev_state = MOTOR_OPS_STOP;*/
	/*motors[HORIZONTAL_MOTOR].state = MOTOR_OPS_STOP;*/
	/*motors[VERTICAL_MOTOR].state = MOTOR_OPS_STOP;*/

	//重新初始化状态及硬件管脚
	motor_set_default(mdev);
	return;
}

/*******************************************************************************
功能描述: 置常规移动，使其转到中间位置  处理函数
输入参数:
输出参数: mdev //电机设备总管理结构
返回值域:
--------------------------------------------------------------------------------
修改作者: ChenX
修改日期: 2018.6.
修改说明: 实现
*******************************************************************************/
static long motor_ops_goback(struct motor_device *mdev)
{
	struct motor_driver *motors = mdev->motors;
	int sx, sy;
	int cx, cy;
	sx = motors[HORIZONTAL_MOTOR].max_steps >> 1;		//最大值的一半(中间位置)
	sy = motors[VERTICAL_MOTOR].max_steps >> 1;			//最大值的一半(中间位置)
	cx = motors[HORIZONTAL_MOTOR].cur_steps;			//当前值
	cy = motors[VERTICAL_MOTOR].cur_steps;				//当前值
	//printk("sx=%d,sy=%d,cx=%d,cy=%d\n",sx,sy,cx,cy);
	return motor_ops_move(mdev, sx-cx, sy-cy);			//置常规移动，使其转到中间位置
}

/*******************************************************************************
功能描述: 获得当前运行信息函数
输入参数:
输出参数: mdev //电机设备总管理结构
返回值域:
--------------------------------------------------------------------------------
修改作者: ChenX
修改日期: 2018.6.
修改说明: 实现
*******************************************************************************/
static long motor_ops_cruise(struct motor_device *mdev)
{
	unsigned long flags;
	struct motor_driver *motors = mdev->motors;
	//摆中
	motor_ops_goback(mdev);
	//锁
	mutex_lock(&mdev->dev_mutex);
	spin_lock_irqsave(&mdev->slock, flags);
	//置成巡航模式
	mdev->dev_state = MOTOR_OPS_CRUISE;
	motors[HORIZONTAL_MOTOR].state = MOTOR_OPS_CRUISE;
	motors[VERTICAL_MOTOR].state = MOTOR_OPS_CRUISE;

	spin_unlock_irqrestore(&mdev->slock, flags);
	mutex_unlock(&mdev->dev_mutex);

	jz_tcu_enable_counter(mdev->tcu);
	mdev->hl_tcuDisableFlag = 0;
	return 0;
}

/*******************************************************************************
功能描述: 获得当前运行信息函数
输入参数: mdev //电机设备总管理结构
输出参数: msg  //步数，速度，运行等状态信息
返回值域:
--------------------------------------------------------------------------------
修改作者: ChenX
修改日期: 2018.6.
修改说明: 实现
*******************************************************************************/
static void motor_get_message(struct motor_device *mdev, struct motor_message *msg)
{
	struct motor_driver *motors = mdev->motors;
	msg->x = motors[HORIZONTAL_MOTOR].cur_steps;
	msg->y = motors[VERTICAL_MOTOR].cur_steps;
	msg->speed = mdev->tcu_speed;
	if(mdev->dev_state == MOTOR_OPS_STOP)
		msg->status = MOTOR_IS_STOP;
	else
		msg->status = MOTOR_IS_RUNNING;
	return;
}

//检测是不是已经到(转过)最大值，到了返-1
static inline int motor_ops_reset_check_params(struct motor_reset_data *rdata)
{
	if(rdata->x_max_steps == 0 || rdata->y_max_steps == 0)
	{
		return -1;
	}
	if(rdata->x_max_steps < rdata->x_cur_step || rdata->x_max_steps < rdata->x_cur_step)
	{
		return -1;
	}
	return 0;
}

static long motor_ops_reset(struct motor_device *mdev, struct motor_reset_data *rdata)
{
	unsigned long flags;
	int index = 0;
	long ret = 0;
	int times = 0;
	struct motor_message msg;
	printk("%s%d\n",__func__,__LINE__);

	if(mdev == NULL || rdata == NULL)
	{
		printk("ERROR: the parameters of %s is wrong!!\n",__func__);
		return -EPERM;
	}

	if(motor_ops_reset_check_params(rdata) == 0)
	{
		/* app set max steps and current pos */
		mutex_lock(&mdev->dev_mutex);
		spin_lock_irqsave(&mdev->slock, flags);
		mdev->motors[HORIZONTAL_MOTOR].max_steps = rdata->x_max_steps;
		mdev->motors[HORIZONTAL_MOTOR].cur_steps = rdata->x_cur_step;
		mdev->motors[VERTICAL_MOTOR].max_steps = rdata->y_max_steps;
		mdev->motors[VERTICAL_MOTOR].cur_steps = rdata->y_cur_step;
		spin_unlock_irqrestore(&mdev->slock, flags);
		mutex_unlock(&mdev->dev_mutex);
	}
	else
	{
		/* driver calculate max steps. */
		mutex_lock(&mdev->dev_mutex);
		spin_lock_irqsave(&mdev->slock, flags);

		for(index = 0; index < HAS_MOTOR_CNT; index++)
		{
			mdev->motors[index].move_dir = MOTOR_MOVE_RIGHT_UP;
			mdev->motors[index].state = MOTOR_OPS_RESET;
			mdev->motors[index].cur_steps = 0x0;
		}
		mdev->dst_move.one.x = mdev->motors[HORIZONTAL_MOTOR].max_steps;
		mdev->dst_move.one.y = mdev->motors[VERTICAL_MOTOR].max_steps;
		mdev->dst_move.times = 1;
		mdev->cur_move.one.x = 0;
		mdev->cur_move.one.y = 0;
		mdev->cur_move.times = 0;
		mdev->dev_state = MOTOR_OPS_RESET;

		spin_unlock_irqrestore(&mdev->slock, flags);
		mutex_unlock(&mdev->dev_mutex);
		jz_tcu_enable_counter(mdev->tcu);
		mdev->hl_tcuDisableFlag = 0;

		for(index = 0; index < HAS_MOTOR_CNT; index++)
		{
			do{
				ret = wait_for_completion_interruptible_timeout(&mdev->motors[index].reset_completion, msecs_to_jiffies(150000));
				if(ret == 0)
				{
					ret = -ETIMEDOUT;
					goto exit;
				}
			}while(ret == -ERESTARTSYS);
		}
	}
	//printk("x_max = %d, y_max = %d\n", mdev->motors[HORIZONTAL_MOTOR].max_steps,
			//mdev->motors[VERTICAL_MOTOR].max_steps);

	motor_ops_move(mdev,-mdev->motors[HORIZONTAL_MOTOR].max_steps,-mdev->motors[VERTICAL_MOTOR].max_steps);
	do{
		msleep(10);
		motor_get_message(mdev, &msg);
		times++;
		if(times > 1000)
		{
			printk("ERROR:wait motor timeout %s%d\n",__func__,__LINE__);
			ret = -ETIMEDOUT;
			goto exit;
		}
	}while(msg.status == MOTOR_IS_RUNNING);

	ret = motor_ops_goback(mdev);
	/*ret =  motor_ops_move(mdev, (mdev->motors[HORIZONTAL_MOTOR].max_steps) >> 1, */
			/*(mdev->motors[VERTICAL_MOTOR].max_steps) >> 1);*/
	times=0;
	do{
		msleep(10);
		motor_get_message(mdev, &msg);
		times++;
		if(times > 1000)
		{
			printk("ERROR:wait motor timeout %s%d\n",__func__,__LINE__);
			ret = -ETIMEDOUT;
			goto exit;
		}
	}while(msg.status == MOTOR_IS_RUNNING);
	ret = 0;

	/* sync data */
	 rdata->x_max_steps	= mdev->motors[HORIZONTAL_MOTOR].max_steps;
	 rdata->x_cur_step	= mdev->motors[HORIZONTAL_MOTOR].cur_steps;
	 rdata->y_max_steps	= mdev->motors[VERTICAL_MOTOR].max_steps;
	 rdata->y_cur_step	= mdev->motors[VERTICAL_MOTOR].cur_steps;

exit:
	jz_tcu_disable_counter(mdev->tcu);
	mdev->hl_tcuDisableFlag = 1;
	msleep(10);
	motor_set_default(mdev);
	return ret;
}

/*******************************************************************************
功能描述: 设置速度
输入参数: mdev //电机设备总管理结构
输出参数: speed  //速度，多少个脉冲每秒
返回值域:
--------------------------------------------------------------------------------
修改作者: ChenX
修改日期: 2018.6.
修改说明: 实现
*******************************************************************************/
static int motor_speed(struct motor_device *mdev, int speed)
{
#if 0
	__asm__("ssnop");
	if ((speed < MOTOR_MIN_SPEED) || (speed > MOTOR_MAX_SPEED))
	{
		dev_err(mdev->dev, "speed(%d) set error\n", speed);
		return -1;
	}
	__asm__("ssnop");

	mdev->tcu_speed = speed;
	jz_tcu_set_period(mdev->tcu, (24000000 / 64 / mdev->tcu_speed));
#else
	int i = 0;
	int j = 0;

	for (i=1; i<(HL_NUM_OF_LEVEL-1); i++)
	{
		if (speed <= mdev->hl_TimerSpeed/g_traceSpeedList[i])
		{
			break;
		}
	}
	for (j=0; j<HAS_MOTOR_CNT; j++)
	{
		mdev->motors[j].hl_outputDst = i-1;
	}
	printk("[%s%d] speed:%d, level:%d\n",__func__,__LINE__,speed,i-1);
	mdev->tcu_speed = speed;	//假的，此值没用

#endif
	return 0;
}



//***************************************************/
/*						文件操作						*/

static int motor_open(struct inode *inode, struct file *file)
{
	struct miscdevice *dev = file->private_data;
	struct motor_device *mdev = container_of(dev, struct motor_device, misc_dev);
	int ret = 0;

	if(mdev->flag)
	{
		ret = -EBUSY;
		dev_err(mdev->dev, "Motor driver busy now!\n");
	}
	else
	{
		mdev->flag = 1;
	}

	return ret;
}

static int motor_release(struct inode *inode, struct file *file)
{
	struct miscdevice *dev = file->private_data;
	struct motor_device *mdev = container_of(dev, struct motor_device, misc_dev);
	motor_ops_stop(mdev);
	mdev->flag = 0;
	return 0;
}

//***************************************************/
/*						操作接口						*/

static long motor_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	struct miscdevice *dev = filp->private_data;
	struct motor_device *mdev = container_of(dev, struct motor_device, misc_dev);
	long ret = 0;

	if(mdev->flag == 0)
	{
		printk("Please Open /dev/motor Firstly\n");
		return -EPERM;
	}

	switch (cmd)
	{
		//电机停止操作
		case MOTOR_STOP:
			motor_ops_stop(mdev);
			/*printk("MOTOR_STOP!!!!!!!!!!!!!!!!!!!\n");*/
			break;
		//电机复位操作
		case MOTOR_RESET:
			{
				struct motor_reset_data rdata;
				if(arg == 0)
				{
					ret = -EPERM;
					break;
				}
				if (copy_from_user(&rdata, (void __user *)arg, sizeof(rdata)))
				{
					dev_err(mdev->dev, "[%s][%d] copy from user error\n",__func__, __LINE__);
					return -EFAULT;
				}
				ret = motor_ops_reset(mdev, &rdata);
				if(!ret)
				{
					if (copy_to_user((void __user *)arg, &rdata,sizeof(rdata)))
					{
						dev_err(mdev->dev, "[%s][%d] copy to user error\n",__func__, __LINE__);
						return -EFAULT;
					}
				}
				/*printk("MOTOR_RESET!!!!!!!!!!!!!!!!!!!\n");*/
				break;
			}
		//电机移动操作
		case MOTOR_MOVE:
			{
				struct motors_steps dst;
				if (copy_from_user(&dst, (void __user *)arg,sizeof(struct motors_steps)))
				{
					dev_err(mdev->dev, "[%s][%d] copy from user error\n",__func__, __LINE__);
					return -EFAULT;
				}

				ret = motor_ops_move(mdev, dst.x, dst.y);
				/*printk("MOTOR_MOVE!!!!!!!!!!!!!!!!!!!\n");*/
			}
			break;
		//返回电机状态操作
		case MOTOR_GET_STATUS:
			{
				struct motor_message msg;

				motor_get_message(mdev, &msg);
				if (copy_to_user((void __user *)arg, &msg,sizeof(struct motor_message)))
				{
					dev_err(mdev->dev, "[%s][%d] copy to user error\n",__func__, __LINE__);
					return -EFAULT;
				}
			}
			/*printk("MOTOR_GET_STATUS!!!!!!!!!!!!!!!!!!\n");*/
			break;
		//设置电机速度操作
		case MOTOR_SPEED:
			{
				int speed;

				if (copy_from_user(&speed, (void __user *)arg, sizeof(int)))
				{
					dev_err(mdev->dev, "[%s][%d] copy to user error\n", __func__, __LINE__);
					return -EFAULT;
				}

				motor_speed(mdev, speed);
			}
			/*printk("MOTOR_SPEED!!!!!!!!!!!!!!!!!!!!!!!\n");*/
			break;
		//电机摆中操作
		case MOTOR_GOBACK:
			/*printk("MOTOR_GOBACK!!!!!!!!!!!!!!!!!!!!!!!\n");*/
			ret = motor_ops_goback(mdev);
			break;
		//巡航操作
		case MOTOR_CRUISE:
			/*printk("MOTOR_CRUISE!!!!!!!!!!!!!!!!!!!!!!!\n");*/
			ret = motor_ops_cruise(mdev);
			break;
		case MOTOR_TRACE:
		{
			struct motors_steps curDstOps;
			if (copy_from_user(&curDstOps, (void __user *)arg, sizeof(struct motors_steps)))
			{
				dev_err(mdev->dev, "[%s][%d] copy from user error\n",__func__, __LINE__);
				return -EFAULT;
			}

			ret = motor_ops_trace(mdev, curDstOps.x, curDstOps.y);
			/*printk("MOTOR_MOVE!!!!!!!!!!!!!!!!!!!\n");*/
		}
		break;

		default:
			return -EINVAL;
	}

	return ret;
}


static struct file_operations motor_fops = {
	.open = motor_open,
	.release = motor_release,
	.unlocked_ioctl = motor_ioctl,
};

static int motor_info_show(struct seq_file *m, void *v)
{
	int len = 0;
	struct motor_device *mdev = (struct motor_device *)(m->private);
	struct motor_message msg;
	int index = 0;

	len += seq_printf(m ,"The version of Motor driver is %s\n",JZ_MOTOR_DRIVER_VERSION);
	len += seq_printf(m ,"Motor driver is %s\n", mdev->flag?"opened":"closed");
	len += seq_printf(m ,"The max speed is %d and the min speed is %d\n", MOTOR_MAX_SPEED, MOTOR_MIN_SPEED);
	motor_get_message(mdev, &msg);
	len += seq_printf(m ,"The status of motor is %s\n", msg.status?"running":"stop");
	len += seq_printf(m ,"The pos of motor is (%d, %d)\n", msg.x, msg.y);
	len += seq_printf(m ,"The speed of motor is %d\n", msg.speed);

	for(index = 0; index < HAS_MOTOR_CNT; index++)
	{
		len += seq_printf(m ,"## motor is %s ##\n", mdev->motors[index].pdata->name);
		len += seq_printf(m ,"max steps %d\n", mdev->motors[index].max_steps);
		len += seq_printf(m ,"motor direction %d\n", mdev->motors[index].move_dir);
		len += seq_printf(m ,"motor state %d(normal; cruise; reset)\n", mdev->motors[index].state);
		len += seq_printf(m ,"the irq's counter of max pos is %d\n", mdev->motors[index].max_pos_irq_cnt);
		len += seq_printf(m ,"the irq's counter of min pos is %d\n", mdev->motors[index].min_pos_irq_cnt);
	}
	return len;
}

static int motor_info_open(struct inode *inode, struct file *file)
{
	return single_open_size(file, motor_info_show, PDE_DATA(inode),1024);
}

static const struct file_operations motor_info_fops ={
	.read = seq_read,
	.open = motor_info_open,
	.llseek = seq_lseek,
	.release = single_release,
};

//电机初始化
static int motor_probe(struct platform_device *pdev)
{
	int i, ret = 0;
	struct motor_device *mdev;
	struct motor_driver *motor = NULL;
	struct proc_dir_entry *proc;
	printk("%s [ChenX @ Hualai Technologies]\n",__func__);
	printk("Hualai motor driver version: %s\n",HL_MOTOR_DRIVER_VERSION);
	//设置设备信息
	mdev = devm_kzalloc(&pdev->dev, sizeof(struct motor_device), GFP_KERNEL);
	if (!mdev)
	{
		ret = -ENOENT;
		dev_err(&pdev->dev, "kzalloc motor device memery error\n");
		goto error_devm_kzalloc;
	}

	mdev->cell = mfd_get_cell(pdev);
	if (!mdev->cell)
	{
		ret = -ENOENT;
		dev_err(&pdev->dev, "Failed to get mfd cell for jz_adc_aux!\n");
		goto error_devm_kzalloc;
	}

	//设置设备信息
	mdev->dev = &pdev->dev;
	mdev->tcu = (struct jz_tcu_chn *)mdev->cell->platform_data;
	mdev->tcu->irq_type = FULL_IRQ_MODE;
	mdev->tcu->clk_src = TCU_CLKSRC_EXT;
	mdev->tcu->prescale = TCU_PRESCALE_64;

	//设置初始速度
	for(i=0; i < HAS_MOTOR_CNT; i++)
	{
		mdev->motors[i].hl_outputDst = HL_NUM_OF_LEVEL-6;
		mdev->motors[i].hl_traceCur	= 0;
	}

	mdev->tcu_speed = MOTOR_MAX_SPEED;		//JZ-->ChenX
	mdev->hl_TimerSpeed = HL_TRACE_TIMER_SPEED;
	jz_tcu_config_chn(mdev->tcu);
	//jz_tcu_set_period(mdev->tcu, (24000000 / 64 / mdev->tcu_speed));	//JZ-->ChenX
	jz_tcu_set_period(mdev->tcu, (24000000 / 64 / mdev->hl_TimerSpeed));
	//开启timer中断
	jz_tcu_start_counter(mdev->tcu);

	mutex_init(&mdev->dev_mutex);
	spin_lock_init(&mdev->slock);

	platform_set_drvdata(pdev, mdev);

	for(i = 0; i < HAS_MOTOR_CNT; i++)
	{
		motor = &(mdev->motors[i]);
		motor->pdata = &motors_pdata[i];
		motor->move_dir	= MOTOR_MOVE_STOP;
		init_completion(&motor->reset_completion);
		if(motor->pdata->motor_enable)
		{
			if (motor->pdata->motor_st1_gpio != -1)
			{
				gpio_request(motor->pdata->motor_st1_gpio, "motor_st1_gpio");
			}
			if (motor->pdata->motor_st2_gpio != -1)
			{
				gpio_request(motor->pdata->motor_st2_gpio, "motor_st2_gpio");
			}
			if (motor->pdata->motor_st3_gpio != -1)
			{
				gpio_request(motor->pdata->motor_st3_gpio, "motor_st3_gpio");
			}
			if (motor->pdata->motor_st4_gpio != -1)
			{
				gpio_request(motor->pdata->motor_st4_gpio, "motor_st4_gpio");
			}
		}
	}

	mdev->motors[HORIZONTAL_MOTOR].max_steps = hmaxstep+100;
	mdev->motors[VERTICAL_MOTOR].max_steps = vmaxstep+30;

	//jzgpio_ctrl_pull(GPIO_PORT_C, 1, 1<<13);
	//jzgpio_ctrl_pull(GPIO_PORT_C, 1, 1<<14);
	//jzgpio_ctrl_pull(GPIO_PORT_C, 1, 1<<18);

	mdev->run_step_irq = platform_get_irq(pdev,0);
	if (mdev->run_step_irq < 0)
	{
		ret = mdev->run_step_irq;
		dev_err(&pdev->dev, "Failed to get platform irq: %d\n", ret);
		goto error_get_irq;
	}

	ret = request_irq(mdev->run_step_irq, jz_timer_interrupt, 0,
				"jz_timer_interrupt", mdev);
	if (ret)
	{
		dev_err(&pdev->dev, "Failed to run request_irq() !\n");
		goto error_request_irq;
	}

	init_completion(&mdev->stop_completion);
	mdev->wait_stop = 0;
	mdev->misc_dev.minor = MISC_DYNAMIC_MINOR;
	mdev->misc_dev.name = "motor";
	mdev->misc_dev.fops = &motor_fops;
	ret = misc_register(&mdev->misc_dev);
	if (ret < 0)
	{
		ret = -ENOENT;
		dev_err(&pdev->dev, "misc_register failed\n");
		goto error_misc_register;
	}

	/* debug info */
	proc = jz_proc_mkdir("motor");
	if (!proc)
	{
		mdev->proc = NULL;
		printk("create dev_attr_isp_info failed!\n");
	}
	else
	{
		mdev->proc = proc;
	}
	proc_create_data("motor_info", S_IRUGO, proc, &motor_info_fops, (void *)mdev);

	motor_set_default(mdev);
	mdev->flag = 0;
	//printk("%s%d\n",__func__,__LINE__);
	return 0;

error_misc_register:
	free_irq(mdev->run_step_irq, mdev);
error_request_irq:
error_get_irq:
	for(i = 0; i < HAS_MOTOR_CNT; i++)
	{
		motor = &(mdev->motors[i]);
		if(motor->pdata == NULL)
			continue;
		if(motor->pdata->motor_enable)
		{
			if (motor->pdata->motor_st1_gpio != -1)
			{
				gpio_free(motor->pdata->motor_st1_gpio);
			}
			if (motor->pdata->motor_st2_gpio != -1)
			{
				gpio_free(motor->pdata->motor_st2_gpio);
			}
			if (motor->pdata->motor_st3_gpio != -1)
			{
				gpio_free(motor->pdata->motor_st3_gpio);
			}
			if (motor->pdata->motor_st4_gpio != -1)
			{
				gpio_free(motor->pdata->motor_st4_gpio);
			}
		}
		motor->pdata = 0;
		motor->min_pos_irq = 0;
		motor->max_pos_irq = 0;
	}
	kfree(mdev);
error_devm_kzalloc:
	return ret;
}

static int motor_remove(struct platform_device *pdev)
{
	int i;
	struct motor_device *mdev = platform_get_drvdata(pdev);
	struct motor_driver *motor = NULL;

	jz_tcu_disable_counter(mdev->tcu);
	jz_tcu_stop_counter(mdev->tcu);
	mutex_destroy(&mdev->dev_mutex);

	free_irq(mdev->run_step_irq, mdev);
	for(i = 0; i < HAS_MOTOR_CNT; i++)
	{
		motor = &(mdev->motors[i]);
		if(motor->pdata == NULL)
			continue;
		if(motor->pdata->motor_enable)
		{
			if (motor->pdata->motor_st1_gpio != -1)
			{
				gpio_free(motor->pdata->motor_st1_gpio);
			}
			if (motor->pdata->motor_st2_gpio != -1)
			{
				gpio_free(motor->pdata->motor_st2_gpio);
			}
			if (motor->pdata->motor_st3_gpio != -1)
			{
				gpio_free(motor->pdata->motor_st3_gpio);
			}
			if (motor->pdata->motor_st4_gpio != -1)
			{
				gpio_free(motor->pdata->motor_st4_gpio);
			}
		}
		motor->pdata = 0;
		motor->min_pos_irq = 0;
		motor->max_pos_irq = 0;
		motor->min_pos_irq_cnt = 0;
		motor->max_pos_irq_cnt = 0;
	}

	if (mdev->proc)
		proc_remove(mdev->proc);
	misc_deregister(&mdev->misc_dev);

	kfree(mdev);
	return 0;
}

static struct platform_driver motor_driver = {
	.probe = motor_probe,
	.remove = motor_remove,
	.driver = {
		.name	= "tcu_chn2",
		.owner	= THIS_MODULE,
	}
};

static int __init motor_init(void)
{
	return platform_driver_register(&motor_driver);
}

static void __exit motor_exit(void)
{
	platform_driver_unregister(&motor_driver);
}

module_init(motor_init);
module_exit(motor_exit);

MODULE_LICENSE("GPL");
