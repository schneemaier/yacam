/*
 * Copyright (C) 2015 Ingenic Semiconductor Co.,Ltd
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef __MOTOR_H__
#define __MOTOR_H__

#include <linux/wait.h>
#include <linux/spinlock.h>
#include <linux/seq_file.h>
#include <linux/proc_fs.h>
#include <jz_proc.h>
/*
 *  HORIZONTAL is X axis and VERTICAL is Y axis;
 *  while the Zero point is left-bottom, Origin point
 *  is cross point of horizontal midpoint and vertical midpoint.
*/
//华来驱动版本控制，驱动类型+修改日期+当日修改次数对应的字母
#define HL_MOTOR_DRIVER_VERSION			"MT20180918g"//"MT20180716b"
#define USE_INGENIC_T20					1
#define USE_INGENIC_T30					0
#define DRIVER_DEBUG					0
/*#define PLATFORM_HAS_HORIZONTAL_MOTOR 	1*/
/*#define PLATFORM_HAS_VERTICAL_MOTOR 	1*/

enum jz_motor_cnt {
	HORIZONTAL_MOTOR,		//下云台电机
	VERTICAL_MOTOR,			//上云台电机
	HAS_MOTOR_CNT,
};

#if USE_INGENIC_T20
//君正t20对应的硬件设置
/*************************** HORIZONTAL  MOTOR ************************************/
#define HORIZONTAL_MIN_GPIO		-1	/**< motor start point */
#define HORIZONTAL_MAX_GPIO		-1	/**< motor stop point */
#define HORIZONTAL_GPIO_LEVEL	0		/**< motor irq style */

#define HORIZONTAL_ST1_GPIO		GPIO_PB(22)	/**< Phase A */
#define HORIZONTAL_ST2_GPIO		GPIO_PB(21)	/**< Phase B */
#define HORIZONTAL_ST3_GPIO		GPIO_PB(20)	/**< Phase C */
#define HORIZONTAL_ST4_GPIO		GPIO_PB(19)	/**< Phase D */
#define HORIZONTAL_ENABLE		1			//0disable  1enable
/*************************** VERTICAL  MOTOR ************************************/
#define VERTICAL_MIN_GPIO		-1
#define VERTICAL_MAX_GPIO		-1
#define VERTICAL_GPIO_LEVEL		0

#define VERTICAL_ST1_GPIO		GPIO_PC(11)
#define VERTICAL_ST2_GPIO		GPIO_PC(12)
#define VERTICAL_ST3_GPIO		GPIO_PC(15)
#define VERTICAL_ST4_GPIO		GPIO_PC(16)
#define VERTICAL_ENABLE			1			//0disable  1enable
/****************************** MOTOR END ************************************/
#elif USE_INGENIC_T30
//君正t30对应的硬件设置
/*************************** HORIZONTAL  MOTOR ************************************/
#define HORIZONTAL_MIN_GPIO		-1	/**< motor start point */
#define HORIZONTAL_MAX_GPIO		-1	/**< motor stop point */
#define HORIZONTAL_GPIO_LEVEL	0		/**< motor irq style */

#define HORIZONTAL_ST1_GPIO		GPIO_PD(18)	/**< Phase A */
#define HORIZONTAL_ST2_GPIO		GPIO_PD(8)	/**< Phase B */
#define HORIZONTAL_ST3_GPIO		GPIO_PD(7)	/**< Phase C */
#define HORIZONTAL_ST4_GPIO		GPIO_PD(6)	/**< Phase D */
#define HORIZONTAL_ENABLE		1			//0disable  1enable
/*************************** VERTICAL  MOTOR ************************************/
#define VERTICAL_MIN_GPIO		-1
#define VERTICAL_MAX_GPIO		-1
#define VERTICAL_GPIO_LEVEL		0

#define VERTICAL_ST1_GPIO		GPIO_PD(14)
#define VERTICAL_ST2_GPIO		GPIO_PD(9)
#define VERTICAL_ST3_GPIO		GPIO_PD(13)
#define VERTICAL_ST4_GPIO		GPIO_PD(12)
#define VERTICAL_ENABLE			1			//0disable  1enable
/****************************** MOTOR END ************************************/
#else
#endif

/* ioctl cmd */
#define MOTOR_STOP		0x1
#define MOTOR_RESET		0x2
#define MOTOR_MOVE		0x3
#define MOTOR_GET_STATUS	0x4
#define MOTOR_SPEED		0x5
#define MOTOR_GOBACK	0x6
#define MOTOR_CRUISE	0x7
#define MOTOR_TRACE		0X8

/* motor speed */
#define MOTOR_MAX_SPEED	900		/**< unit: beats per second */
#define MOTOR_MIN_SPEED	100

#define HL_NUM_OF_LEVEL				(20)		//速度等级个数
#define HL_TRACE_TIMER_SPEED		(5000)		//定时器速度
#define HL_STOP_TRACE_RANGE_X		(60)		//最低速的位置
#define HL_STOP_TRACE_RANGE_Y		(40)		//最低速的位置
#define HL_STOP_TRACE_CUTIN_X		(210)		//cut in,no trace最高速的位置
#define HL_STOP_TRACE_CUTIN_Y		(110)		//cut in,no trace最高速的位置
#define HL_TRACE_RANGE_X			(320)		//最高速的位置
#define HL_TRACE_RANGE_Y			(180)		//最高速的位置
#define HL_TRACE_X_MUL				((HL_TRACE_RANGE_X - HL_STOP_TRACE_RANGE_X) / HL_NUM_OF_LEVEL)
#define HL_TRACE_Y_MUL				((HL_TRACE_RANGE_Y - HL_STOP_TRACE_RANGE_Y) / HL_NUM_OF_LEVEL)
#define HL_TRACE_STOP_TIME_MAX		(5 * 1500)	//最DA
#define HL_TRACE_CMD_TIMEOUT		(5 * 130)//(HL_TRACE_TIMER_SPEED * 130 / 1000)	//130ms没更新，则减速停止
#define HL_EXCHANGE_SPEED_LVL_CNT	(5 * 20)//(HL_TRACE_TIMER_SPEED * 20 / 1000)	//17MS每级

//是否移动状态
enum motor_status {
	MOTOR_IS_STOP,		//停止状态
	MOTOR_IS_RUNNING,	//正在动状态
};

//电机的参数消息
struct motor_message {
	int x;			//电机1的步数
	int y;			//电机2的步数
	enum motor_status status;	//是否移动状态
	int speed;		//移动速度
};

//计步变量
struct motors_steps{
	int x;
	int y;
};

struct motor_reset_data {
	unsigned int x_max_steps;
	unsigned int y_max_steps;
	unsigned int x_cur_step;
	unsigned int y_cur_step;
};

//电机运动方向
enum motor_direction {
	MOTOR_MOVE_LEFT_DOWN = -1,		//减小
	MOTOR_MOVE_STOP,				//不变
	MOTOR_MOVE_RIGHT_UP,			//增大
};

//硬件参数
struct motor_platform_data {
	const char name[32];
	unsigned int motor_min_gpio;
	unsigned int motor_max_gpio;
	int motor_gpio_level;

	unsigned int motor_st1_gpio;
	unsigned int motor_st2_gpio;
	unsigned int motor_st3_gpio;
	unsigned int motor_st4_gpio;
	unsigned int motor_enable;
};

//电机处于的运动模式
enum motor_ops_state {
	MOTOR_OPS_NORMAL,		//常规移动
	MOTOR_OPS_CRUISE,		//巡航
	MOTOR_OPS_RESET,		//复位
	MOTOR_OPS_STOP,			//停止
	MOTOR_OPS_TRACE			//追踪    新加
};

/* It is right-top point when x is max and y is max.*/
/* It is left-bottom point when x is 0 and y is 0.*/
//单个电机状态管理结构
struct motor_driver {
	struct motor_platform_data *pdata;		//硬件参数
	int max_pos_irq;
	int min_pos_irq;
	int max_steps;							//本电机转到最右或最上时的步数
	int cur_steps;							//本电机当前步数
	int total_steps;						//本电机的总步数
	char reset_min_pos;						//复位状态下最小达到的位置
	char reset_max_pos;						//复位状态下最大达到的位置
	enum motor_direction move_dir;			//实际移动方向
	enum motor_ops_state state;				//电机处于的运动模式
	struct completion reset_completion;		//复位完成变量
	int hl_outputCurCount;					//计数输出，影响单个电机的实际输出速度
	int hl_outputDst;						//计数输出等级，影响单个电机的实际输出速度
	int hl_traceDst;						//追踪的 目标计数输出等级
	int hl_traceCur;						//追踪的 实际计数输出等级
	int hl_traceCurCount;					//追踪的计数输出，(与当前速度等级对应的值对比，判断是否输出)
	int hl_traceStop;						//追踪的速度过小，欲停止追踪(此标志为1时强行减速至停止)
	enum motor_direction hl_traceDstDir;	//追踪的目标移动方向
	struct timer_list min_timer;
	struct timer_list max_timer;
	/* debug parameters */
	unsigned int max_pos_irq_cnt;
	unsigned int min_pos_irq_cnt;
};

//移动参数，x y步数值，时间值
struct motor_move {
	struct motors_steps one;
	short times;
};

//电机设备总管理结构
struct motor_device {
	struct platform_device *pdev;
	const struct mfd_cell *cell;
	struct device	 *dev;
	struct miscdevice misc_dev;
	struct motor_driver motors[HAS_MOTOR_CNT];	//单个电机状态管理结构
	char *skip_mode;							//跳步模式的步数表。。。没用到
	unsigned int counter;						//步数计数(每次刚开始移动前，清0)
	struct completion stop_completion;			//停止完成消息变量
	unsigned int wait_stop;						//等待发停止消息标志，(0已发消息，非0还没发消息)
	struct jz_tcu_chn *tcu;
	int hl_tcuDisableFlag;						//记录是否使能过tcu (0使能过 1已失能)
	int traceCmdTimeout;						//追踪cmd的有效时间持续计数
	int traceStopTime;							//追踪停止时间计数
	int hl_exchangeSpeedTimeout;				//变换速度等级的时间计数
	int tcu_speed;								//速度(可折合成timer的周期)(目前版本无用)
	int hl_TimerSpeed;							//定时器周期
	struct mutex dev_mutex;						//互斥锁
	spinlock_t slock;							//自旋锁

	enum motor_ops_state dev_state;				//电机处于的运动模式
	struct motor_message msg;					//电机的参数消息
	struct motor_move dst_move;					//移动参数，x y步数值，时间值
	struct motor_move cur_move;					//移动参数，x y步数值，时间值

	int run_step_irq;
	int flag;									//是否打开驱动

	/* debug parameters */
	struct proc_dir_entry *proc;
};


#endif // __MOTOR_H__
