#include <linux/err.h>
#include <linux/irq.h>
#include <linux/interrupt.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/platform_device.h>
#include <linux/miscdevice.h>
#include <linux/mfd/core.h>
#include <linux/mfd/jz_tcu.h>
#include "speakerctl.h"
#include <jz_proc.h>
#include <linux/gpio.h>
#include <soc/gpio.h>
#include <asm/io.h>
#include <linux/delay.h>

static int speakerctl_open(struct inode *inode, struct file *file)
{
	struct miscdevice *dev = file->private_data;
	struct speakerctl_device *mdev = container_of(dev, struct speakerctl_device, misc_dev);
	int ret = 0;
	if(mdev->flag){
		ret = -EBUSY;
		dev_err(mdev->dev, "speakerctl driver busy now!\n");
	}else{
		mdev->flag = 1;
	}

	return ret;
}

static int speakerctl_release(struct inode *inode, struct file *file)
{
	struct miscdevice *dev = file->private_data;
	struct speakerctl_device *mdev = container_of(dev, struct speakerctl_device, misc_dev);
	//speakerctl_ops_stop(mdev);
	mdev->flag = 0;
	return 0;
}

static long speakerctl_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	struct miscdevice *dev = filp->private_data;
	struct speakerctl_device *mdev = container_of(dev, struct speakerctl_device, misc_dev);
	long ret = 0;

	if(mdev->flag == 0){
		printk("Please Open /dev/speakerctl Firstly\n");
		return -EPERM;
	}

	switch (cmd) {
		case SPEAKERCTL_MODE0:
			gpio_direction_output(GPIO_PB(31), 0);
			printk("SPEAKERCTL_MODE0!!!!!!!!!!!!!!!!!!!\n");
			break;	
		case SPEAKERCTL_MODE1:
			gpio_direction_output(GPIO_PB(31), 1);
			printk("SPEAKERCTL_MODE1!!!!!!!!!!!!!!!!!!!\n");
			break;	
		case SPEAKERCTL_MODE2:
			gpio_direction_output(GPIO_PB(31), 1);
			udelay(5);
			gpio_direction_output(GPIO_PB(31), 0);
			udelay(5);
			gpio_direction_output(GPIO_PB(31), 1);
			printk("SPEAKERCTL_MODE2!!!!!!!!!!!!!!!!!!!\n");
			break;
		case SPEAKERCTL_MODE3:
			gpio_direction_output(GPIO_PB(31), 1);
			udelay(5);
			gpio_direction_output(GPIO_PB(31), 0);
			udelay(5);
			gpio_direction_output(GPIO_PB(31), 1);
			udelay(5);
			gpio_direction_output(GPIO_PB(31), 0);
			udelay(5);
			gpio_direction_output(GPIO_PB(31), 1);
			printk("SPEAKERCTL_MODE3!!!!!!!!!!!!!!!!!!!\n");
			break;	
		case SPEAKERCTL_MODE4:
			gpio_direction_output(GPIO_PB(31), 1);
			udelay(5);
			gpio_direction_output(GPIO_PB(31), 0);
			udelay(5);
			gpio_direction_output(GPIO_PB(31), 1);
			udelay(5);
			gpio_direction_output(GPIO_PB(31), 0);
			udelay(5);
			gpio_direction_output(GPIO_PB(31), 1);
			udelay(5);
			gpio_direction_output(GPIO_PB(31), 0);
			udelay(5);
			gpio_direction_output(GPIO_PB(31), 1);
			printk("SPEAKERCTL_MODE4!!!!!!!!!!!!!!!!!!!\n");
			break;
		//default:
			//return -EINVAL;
	}

	return ret;
}

static struct file_operations speakerctl_fops = {
	.open = speakerctl_open,
	.release = speakerctl_release,
	.unlocked_ioctl = speakerctl_ioctl,
};

static int speakerctl_info_show(struct seq_file *m, void *v)
{
	int len = 0;
	struct speakerctl_device *mdev = (struct speakerctl_device *)(m->private);
	/*struct speakerctl_message msg;
	int index = 0;

	len += seq_printf(m ,"The version of speakerctl driver is %s\n",JZ_speakerctl_DRIVER_VERSION);
	len += seq_printf(m ,"speakerctl driver is %s\n", mdev->flag?"opened":"closed");
	speakerctl_get_message(mdev, &msg);
	len += seq_printf(m ,"The status of speakerctl is %s\n", msg.status?"running":"stop");
	len += seq_printf(m ,"The pos of speakerctl is (%d, %d)\n", msg.x, msg.y);
	len += seq_printf(m ,"The speed of speakerctl is %d\n", msg.speed);

	for(index = 0; index < HAS_speakerctl_CNT; index++){
		len += seq_printf(m ,"## speakerctl is %s ##\n", mdev->speakerctls[index].pdata->name);
		len += seq_printf(m ,"max steps %d\n", mdev->speakerctls[index].max_steps);
		len += seq_printf(m ,"speakerctl direction %d\n", mdev->speakerctls[index].move_dir);
		len += seq_printf(m ,"speakerctl state %d(normal; cruise; reset)\n", mdev->speakerctls[index].state);
		len += seq_printf(m ,"the irq's counter of max pos is %d\n", mdev->speakerctls[index].max_pos_irq_cnt);
		len += seq_printf(m ,"the irq's counter of min pos is %d\n", mdev->speakerctls[index].min_pos_irq_cnt);
	}*/
	return len;
}

static int speakerctl_info_open(struct inode *inode, struct file *file)
{
	return single_open_size(file, speakerctl_info_show, PDE_DATA(inode),512);
}

static const struct file_operations speakerctl_info_fops ={
	.read = seq_read,
	.open = speakerctl_info_open,
	.llseek = seq_lseek,
	.release = single_release,
};

static int speakerctl_probe(struct platform_device *pdev)
{	
	int i, ret = 0;
	struct speakerctl_device *mdev;
	struct proc_dir_entry *proc;
	//printk("%s%d\n",__func__,__LINE__);
	mdev = devm_kzalloc(&pdev->dev, sizeof(struct speakerctl_device), GFP_KERNEL);

	mdev->cell = mfd_get_cell(pdev);
	
	mdev->dev = &pdev->dev;
	mdev->tcu = (struct jz_tcu_chn *)mdev->cell->platform_data;

	jz_tcu_config_chn(mdev->tcu);
	mutex_init(&mdev->dev_mutex);
	//spin_lock_init(&mdev->slock);

	platform_set_drvdata(pdev, mdev);

	gpio_request(GPIO_PB(31), "speakerctl_gpio");

	mdev->misc_dev.minor = MISC_DYNAMIC_MINOR;
	mdev->misc_dev.name = "speakerctl";
	mdev->misc_dev.fops = &speakerctl_fops;
	ret = misc_register(&mdev->misc_dev);

	/* debug info */
	proc = jz_proc_mkdir("speakerctl");
	if (!proc) {
		mdev->proc = NULL;
		printk("create dev_attr_isp_info failed!\n");
	} else {
		mdev->proc = proc;
	}
	proc_create_data("speakerctl_info", S_IRUGO, proc, &speakerctl_info_fops, (void *)mdev);

	//speakerctl_set_default(mdev);
	mdev->flag = 0;
	//printk("%s%d\n",__func__,__LINE__);
	return 0;
}

static int speakerctl_remove(struct platform_device *pdev)
{
	int i;
	struct speakerctl_device *mdev = platform_get_drvdata(pdev);

	misc_deregister(&mdev->misc_dev);

	jz_tcu_stop_counter(mdev->tcu);
	mutex_destroy(&mdev->dev_mutex);

	if (mdev->proc)
		proc_remove(mdev->proc);
	return 0;
}

static struct platform_driver speakerctl_driver = {
	.probe = speakerctl_probe,
	.remove = speakerctl_remove,
	.driver = {
		.name	= "tcu_chn3",
		.owner	= THIS_MODULE,
	}
};

static int __init speakerctl_init(void)
{
	return platform_driver_register(&speakerctl_driver);
}

static void __exit speakerctl_exit(void)
{
	platform_driver_unregister(&speakerctl_driver);
}

module_init(speakerctl_init);
module_exit(speakerctl_exit);

MODULE_LICENSE("GPL");

