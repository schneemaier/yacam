/*
 * Copyright (C) 2015 Ingenic Semiconductor Co.,Ltd
 *
 * This software is licensed under the terms of the GNU General Public
 * License version 2, as published by the Free Software Foundation, and
 * may be copied, distributed, and modified under those terms.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef __MOTOR_H__
#define __MOTOR_H__

#include <linux/wait.h>
#include <linux/spinlock.h>
#include <linux/seq_file.h>
#include <linux/proc_fs.h>
#include <jz_proc.h>

struct speakerctl_device {
	const struct mfd_cell *cell;
	struct device	 *dev;
	struct miscdevice misc_dev;
	struct jz_tcu_chn *tcu;
	struct mutex dev_mutex;
	int flag;
	/* debug parameters */
	struct proc_dir_entry *proc;
};

#define SPEAKERCTL_MODE0 0
#define SPEAKERCTL_MODE1 1
#define SPEAKERCTL_MODE2 2
#define SPEAKERCTL_MODE3 3
#define SPEAKERCTL_MODE4 4

#endif // __MOTOR_H__
